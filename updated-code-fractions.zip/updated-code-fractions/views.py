# management_app/views.py
from django.contrib.admin.views.decorators import staff_member_required
from django.shortcuts import render
from django.apps import apps
from django.utils.html import format_html_join
from .models import *

@staff_member_required
def admin_docs(request):
    app_label = "management_app"
    models = [m for m in apps.get_app_config(app_label).get_models()]
    model_docs = []
    for M in models:
        fields = []
        for f in M._meta.get_fields():
            if not getattr(f, "editable", False) and not getattr(f, "primary_key", False):
                # skip non-editable relations except FKs
                pass
            if hasattr(f, "choices") and f.choices:
                choices = ", ".join([str(c[0]) for c in f.choices])
            else:
                choices = ""
            fields.append({
                "name": f.name,
                "type": f.__class__.__name__,
                "null": getattr(f, "null", False),
                "blank": getattr(f, "blank", False),
                "choices": choices,
                "help": getattr(f, "help_text", "") or "",
            })
        model_docs.append({
            "model": M._meta.verbose_name_plural.title(),
            "description": (M.__doc__ or "").strip(),
            "fields": fields,
        })
    return render(request, "admin_docs.html", {"model_docs": model_docs})
import io
from django.http import Http404, HttpResponse
from django.shortcuts import get_object_or_404, render
from django.core import signing
import qrcode
from django.contrib.auth.decorators import login_required, permission_required

def instrument_public_detail(request, pk: int):
    obj = get_object_or_404(Instrument, pk=pk)  # ← is_active filter hata diya
    inactive_msg = None
    if not obj.is_active:
        inactive_msg = "This instrument is archived."
    calibrations = list(obj.calibration_records.order_by("-calibration_date", "-id"))
    latest = calibrations[0] if calibrations else None
    state, due_date, days_left = _cal_state(
        latest and latest.calibration_date, latest and latest.valid_months
    )
    return render(request, "public_detail.html", {
        "obj": obj,
        "inactive_msg": inactive_msg,
        "calibrations": calibrations,
        "latest_cal": latest,
        "cal_state": state,
        "cal_label": CAL_STATE_LABELS[state],
        "cal_due_date": due_date,
        "cal_days_left": days_left,
    })

def instrument_qr_png(request, pk: int):
    obj = get_object_or_404(Instrument, pk=pk)
    public_abs_url = request.build_absolute_uri(obj.get_public_url())
    img = qrcode.make(public_abs_url)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return HttpResponse(buf.getvalue(), content_type="image/png")

from django.db.models import Count, Q, OuterRef, Subquery, Max, F, Value, IntegerField
from django.db.models.functions import TruncMonth, Coalesce
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import TemplateView
from dateutil.relativedelta import relativedelta

# ---- helpers ----
DUE_SOON_DAYS = 30

def _now_date():
    return timezone.now().date()

def _current_dept_subquery():
    current_place = (InstrumentPlacement.objects
        .filter(instrument_id=OuterRef("pk"), end_date__isnull=True)
        .order_by("-start_date", "-id"))
    return Subquery(current_place.values("department_id")[:1])

def annotate_latest_cal(qs):
    """Annotate each Instrument with latest calibration date & validity months (MySQL-safe)."""
    latest_cal = (CalibrationRecord.objects
        .filter(instrument_id=OuterRef("pk"))
        .order_by("-calibration_date", "-id"))
    return qs.annotate(
        last_cal_date=Subquery(latest_cal.values("calibration_date")[:1]),
        last_valid_months=Coalesce(Subquery(latest_cal.values("valid_months")[:1]), Value(0)),
    )

def _status_flag_q():
    return {
        "scrapped": Q(status_history__status=InstrumentStatus.STATUS_SCRAPPED),
        "under_repair": Q(status_history__status=InstrumentStatus.STATUS_REPAIR),
        "in_use": Q(status_history__status=InstrumentStatus.STATUS_IN_USE),
        "spare": Q(status_history__status=InstrumentStatus.STATUS_SPARE),
    }

def _cal_state(last, months, today=None):
    """
    Classify the latest calibration of an instrument.
    Returns (state, due_date, days_left); state is one of
    "never" | "overdue" | "due_soon" | "calibrated".
    Due date matches CalibrationRecord.due_date (calendar months).
    """
    today = today or _now_date()
    months = int(months or 0)
    if not last or months <= 0:
        return "never", None, None
    due_date = last + relativedelta(months=months)
    days_left = (due_date - today).days
    if days_left < 0:
        return "overdue", due_date, days_left
    if days_left <= DUE_SOON_DAYS:
        return "due_soon", due_date, days_left
    return "calibrated", due_date, days_left


def _calc_due_flags(instruments):
    """Return sets of instrument IDs: (calibrated, due_soon, due) using annotated fields."""
    today = _now_date()
    instruments = annotate_latest_cal(instruments)
    ids_due, ids_due_soon, ids_calibrated = set(), set(), set()

    for row in instruments.values("id", "last_cal_date", "last_valid_months"):
        state, _, _ = _cal_state(row["last_cal_date"], row["last_valid_months"], today)
        if state == "calibrated":
            ids_calibrated.add(row["id"])
        elif state == "due_soon":
            ids_due_soon.add(row["id"])
        else:
            ids_due.add(row["id"])

    return ids_calibrated, ids_due_soon, ids_due


# ---- equipment/sensor-wise inventory ----
CAL_CALIBRATED = "calibrated"
CAL_UNCALIBRATED = "uncalibrated"
CAL_STATE_LABELS = {
    "calibrated": "Calibrated",
    "due_soon": "Calibrated (due soon)",
    "overdue": "Uncalibrated (expired)",
    "never": "Uncalibrated (no record)",
}

def _inventory_rows(base_qs):
    """
    One dict per instrument with its equipment/sensor group and latest calibration.
    Group = apparatus name, falling back to the category when it is blank.
    """
    today = _now_date()
    latest_cal = (CalibrationRecord.objects
        .filter(instrument_id=OuterRef("pk"))
        .order_by("-calibration_date", "-id"))
    current_place = (InstrumentPlacement.objects
        .filter(instrument_id=OuterRef("pk"), end_date__isnull=True)
        .order_by("-start_date", "-id"))
    qs = annotate_latest_cal(base_qs).annotate(
        last_cal_certificate=Subquery(latest_cal.values("certificate_no")[:1]),
        last_cal_provider=Subquery(latest_cal.values("provider")[:1]),
        last_cal_method=Subquery(latest_cal.values("method")[:1]),
        last_cal_result=Subquery(latest_cal.values("result")[:1]),
        current_site=Subquery(current_place.values("site")[:1]),
        current_state=Subquery(current_place.values("state")[:1]),
    ).values(
        "id", "name", "gauge_id", "serial_number", "apparatus_name", "make",
        "device_status", "category__name", "model__name", "department__name",
        "last_cal_date", "last_valid_months", "last_cal_certificate",
        "last_cal_provider", "last_cal_method", "last_cal_result",
        "current_site", "current_state",
    )

    rows = []
    for r in qs:
        state, due_date, days_left = _cal_state(r["last_cal_date"], r["last_valid_months"], today)
        item = (r["apparatus_name"] or "").strip() or r["category__name"] or "Uncategorised"
        rows.append({
            "id": r["id"],
            "item": item,
            "name": r["name"],
            "gauge_id": r["gauge_id"],
            "serial": r["serial_number"] or "",
            "category": r["category__name"] or "",
            "model": r["model__name"] or "",
            "make": r["make"] or "",
            "department": r["department__name"] or "",
            "location": ", ".join(x for x in [r["current_site"], r["current_state"]] if x),
            "device_status": (r["device_status"] or "").replace("_", " ").title(),
            "cal_state": state,
            "cal_label": CAL_STATE_LABELS[state],
            "is_calibrated": state in ("calibrated", "due_soon"),
            "last_cal_date": r["last_cal_date"],
            "valid_months": r["last_valid_months"] if r["last_cal_date"] else None,
            "due_date": due_date,
            "days_left": days_left,
            "certificate_no": r["last_cal_certificate"] or "",
            "provider": r["last_cal_provider"] or "",
            "method": (r["last_cal_method"] or "").title(),
            "result": r["last_cal_result"] or "",
        })
    rows.sort(key=lambda x: (x["item"].lower(), x["gauge_id"] or "", x["serial"]))
    return rows


def _inventory_summary(rows):
    """Per equipment/sensor totals: calibrated vs uncalibrated."""
    groups = {}
    for r in rows:
        g = groups.setdefault(r["item"].lower(), {
            "item": r["item"], "total": 0, "calibrated": 0, "due_soon": 0,
            "uncalibrated": 0, "expired": 0, "no_record": 0,
        })
        g["total"] += 1
        if r["is_calibrated"]:
            g["calibrated"] += 1
            if r["cal_state"] == "due_soon":
                g["due_soon"] += 1
        else:
            g["uncalibrated"] += 1
            g["expired" if r["cal_state"] == "overdue" else "no_record"] += 1
    return sorted(groups.values(), key=lambda g: g["item"].lower())


class DashboardView(LoginRequiredMixin, TemplateView):
    template_name = "dashboard.html"

    def get_queryset_scoped(self, request):
        """
        Role-based scoping:
        - superuser/staff: all
        - group 'view_department_only': only instruments in user's department (via current placement)
        """
        qs = Instrument.objects.all()
        if request.user.is_superuser or request.user.is_staff:
            return qs
        if request.user.groups.filter(name="view_department_only").exists():
            user_dept = getattr(getattr(request.user, "profile", None), "department_id", None)
            if user_dept:
                dept_sub = _current_dept_subquery()
                return qs.annotate(current_dept_id=dept_sub).filter(current_dept_id=user_dept)
        return qs

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        request = self.request

        base_qs = self.get_queryset_scoped(request).distinct()
        dept_sub = _current_dept_subquery()
        base_qs = base_qs.annotate(current_dept_id=dept_sub)

        # ---- totals & flags ----
        total_instruments = base_qs.count()

        ids_calibrated, ids_due_soon, ids_due = _calc_due_flags(base_qs)
        count_calibrated = len(ids_calibrated)
        count_due_soon = len(ids_due_soon)
        count_overdue = len(ids_due)

        status_q = _status_flag_q()
        # status counts (approx via existence in history)
        count_scrapped = base_qs.filter(status_q["scrapped"]).count()
        count_repair = base_qs.filter(status_q["under_repair"]).count()
        count_in_use = base_qs.filter(status_q["in_use"]).count()
        count_spare = base_qs.filter(status_q["spare"]).count()

        # ---- department-wise summary ----
        dept_map = dict(Department.objects.values_list("id", "name"))
        dept_rows = {}
        for inst in base_qs.values("id", "current_dept_id"):
            did = inst["current_dept_id"]
            if did not in dept_rows:
                dept_rows[did] = {"department": dept_map.get(did, "Unassigned"),
                                  "total": 0, "calibrated": 0, "due_soon": 0, "overdue": 0,
                                  "in_use": 0, "spare": 0, "repair": 0, "scrapped": 0}
            row = dept_rows[did]
            row["total"] += 1
            iid = inst["id"]
            if iid in ids_calibrated: row["calibrated"] += 1
            if iid in ids_due_soon:   row["due_soon"] += 1
            if iid in ids_due:        row["overdue"] += 1

        # statuses per dept
        for did, counts in dept_rows.items():
            dept_insts = base_qs.filter(current_dept_id=did)
            counts["in_use"]   = dept_insts.filter(status_q["in_use"]).count()
            counts["spare"]    = dept_insts.filter(status_q["spare"]).count()
            counts["repair"]   = dept_insts.filter(status_q["under_repair"]).count()
            counts["scrapped"] = dept_insts.filter(status_q["scrapped"]).count()

        dept_summary = sorted(dept_rows.values(), key=lambda r: (r["department"] or "Unassigned"))

        # ---- charts: monthly trends (last 12 months) ----
        today = _now_date()
        year_ago = (today.replace(day=1) - timedelta(days=365))
        cal_trend = (CalibrationRecord.objects
                     .filter(instrument__in=base_qs, calibration_date__gte=year_ago)
                     .annotate(m=TruncMonth("calibration_date"))
                     .values("m").annotate(c=Count("id")).order_by("m"))
        chart_labels = [f"{row['m']:%Y-%m}" for row in cal_trend]
        chart_values = [row["c"] for row in cal_trend]

        # ---- alerts: upcoming & overdue (MySQL-safe, no DISTINCT ON) ----
        alert_items = []
        ann_qs = annotate_latest_cal(base_qs).values(
            "id", "name", "serial_number", "last_cal_date", "last_valid_months"
        )
        for row in ann_qs:
            iid = row["id"]
            label = f"{row['name']} ({row['serial_number'] or 'no-serial'})"
            state, due_date, days_left = _cal_state(row["last_cal_date"], row["last_valid_months"], today)
            if state == "calibrated":
                continue
            alert_items.append({
                "instrument": label,
                "instrument_id": iid,
                "last_calibration": row["last_cal_date"] if state != "never" else None,
                "due_date": due_date,
                "days_left": -9999 if state == "never" else days_left,  # never => critical
            })
        alert_items.sort(key=lambda x: x["days_left"])

        # ---- quick links (admin filters) ----
        def admin_url(model, params=""):
            return f"/admin/management_app/{model}/?{params}" if params else f"/admin/management_app/{model}/"
        
        # overall compliance (calibrated / total)
        compliance_pct = round((count_calibrated / total_instruments) * 100, 1) if total_instruments else 0.0

        # per-department compliance %
        for r in dept_rows.values():
            t = r["total"] or 1
            r["compliance_pct"] = round((r["calibrated"] / t) * 100, 1)

        ctx.update({
            "total_instruments": total_instruments,
            "count_calibrated": count_calibrated,
            "count_due_soon": count_due_soon,
            "count_overdue": count_overdue,
            "count_in_use": count_in_use,
            "count_spare": count_spare,
            "count_repair": count_repair,
            "count_scrapped": count_scrapped,

            "dept_summary": dept_summary,
            "inventory_summary": _inventory_summary(_inventory_rows(base_qs)),
            "chart_labels": chart_labels,
            "chart_values": chart_values,
            "alert_items": alert_items,

            "link_instruments": admin_url("instrument"),
            "link_calibrations": admin_url("calibrationrecord"),
            "link_status": admin_url("instrumentstatus"),
            "link_due": admin_url("instrument", "q=overdue"),
            "link_bulk": "/admin/",
            "compliance_pct": compliance_pct,
        })
        return ctx


# ---- Exports ----
@login_required
def export_dashboard_csv(request):
    import csv
    view = DashboardView()
    view.request = request
    ctx = view.get_context_data()
    resp = HttpResponse(content_type="text/csv")
    resp["Content-Disposition"] = 'attachment; filename="dashboard_summary.csv"'
    writer = csv.writer(resp)
    writer.writerow(["Department","Total","Calibrated","Due Soon","Overdue","In Use","Spare","Repair","Scrapped"])
    for r in ctx["dept_summary"]:
        writer.writerow([r["department"], r["total"], r["calibrated"], r["due_soon"], r["overdue"],
                         r["in_use"], r["spare"], r["repair"], r["scrapped"]])
    return resp

@login_required
def export_dashboard_xlsx(request):
    try:
        import tablib  # (from django-import-export or install 'tablib')
        view = DashboardView()
        view.request = request
        ctx = view.get_context_data()
        headers = ["Department","Total","Calibrated","Due Soon","Overdue","In Use","Spare","Repair","Scrapped"]
        data = tablib.Dataset(headers=headers)
        for r in ctx["dept_summary"]:
            data.append([r["department"], r["total"], r["calibrated"], r["due_soon"], r["overdue"],
                         r["in_use"], r["spare"], r["repair"], r["scrapped"]])
        resp = HttpResponse(content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        resp["Content-Disposition"] = 'attachment; filename="dashboard_summary.xlsx"'
        resp.write(data.export("xlsx"))
        return resp
    except Exception:
        return export_dashboard_csv(request)
    
INVENTORY_SUMMARY_HEADERS = ["Equipment / Sensor", "Total", "Calibrated", "of which Due Soon",
                             "Uncalibrated", "of which Expired", "of which No Record"]
INVENTORY_DETAIL_HEADERS = ["Equipment / Sensor", "Gauge ID", "Serial No.", "Name", "Make", "Model",
                            "Department", "Location", "Device Status", "Calibration Status",
                            "Calibration Date", "Validity (months)", "Valid Until", "Days Left",
                            "Certificate No.", "Calibrated By", "Method", "Result"]

def _tabular_response(headers, data_rows, filename, fmt):
    if fmt == "xlsx":
        try:
            import tablib
            data = tablib.Dataset(headers=headers)
            for row in data_rows:
                data.append(["" if v is None else v for v in row])
            resp = HttpResponse(content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            resp["Content-Disposition"] = f'attachment; filename="{filename}.xlsx"'
            resp.write(data.export("xlsx"))
            return resp
        except Exception:
            pass
    import csv
    resp = HttpResponse(content_type="text/csv")
    resp["Content-Disposition"] = f'attachment; filename="{filename}.csv"'
    writer = csv.writer(resp)
    writer.writerow(headers)
    for row in data_rows:
        writer.writerow(["" if v is None else v for v in row])
    return resp


@login_required
def inventory_view(request):
    """Equipment/sensor-wise inventory with calibration status and item-level drill-down."""
    view = DashboardView()
    view.request = request
    all_rows = _inventory_rows(view.get_queryset_scoped(request).distinct())
    summary = _inventory_summary(all_rows)

    item = (request.GET.get("item") or "").strip()
    cal = (request.GET.get("cal") or "").strip()
    q = (request.GET.get("q") or "").strip()
    out_format = (request.GET.get("format") or "").strip()
    report = (request.GET.get("report") or "").strip()

    if report == "summary" and out_format in {"csv", "xlsx"}:
        return _tabular_response(
            INVENTORY_SUMMARY_HEADERS,
            [[g["item"], g["total"], g["calibrated"], g["due_soon"],
              g["uncalibrated"], g["expired"], g["no_record"]] for g in summary],
            "inventory_summary", out_format,
        )

    rows = all_rows
    if item:
        rows = [r for r in rows if r["item"].lower() == item.lower()]
    if cal == CAL_CALIBRATED:
        rows = [r for r in rows if r["is_calibrated"]]
    elif cal == CAL_UNCALIBRATED:
        rows = [r for r in rows if not r["is_calibrated"]]
    elif cal in CAL_STATE_LABELS:
        rows = [r for r in rows if r["cal_state"] == cal]
    if q:
        ql = q.lower()
        rows = [r for r in rows if any(
            ql in (r[k] or "").lower()
            for k in ("gauge_id", "serial", "name", "model", "make", "location", "certificate_no")
        )]

    if out_format in {"csv", "xlsx"}:
        return _tabular_response(
            INVENTORY_DETAIL_HEADERS,
            [[r["item"], r["gauge_id"], r["serial"], r["name"], r["make"], r["model"],
              r["department"], r["location"], r["device_status"], r["cal_label"],
              r["last_cal_date"], r["valid_months"], r["due_date"], r["days_left"],
              r["certificate_no"], r["provider"], r["method"], r["result"]] for r in rows],
            "inventory_details", out_format,
        )

    totals = {k: sum(g[k] for g in summary)
              for k in ("total", "calibrated", "due_soon", "uncalibrated", "expired", "no_record")}
    return render(request, "inventory.html", {
        "summary": summary,
        "totals": totals,
        "rows": rows,
        "selected": {"item": item, "cal": cal, "q": q},
        "cal_choices": [
            (CAL_CALIBRATED, "Calibrated"),
            (CAL_UNCALIBRATED, "Uncalibrated"),
            ("due_soon", "Due soon (≤30 days)"),
            ("overdue", "Expired"),
            ("never", "No calibration record"),
        ],
        "export_query": request.GET.urlencode(),
    })


from django.http import JsonResponse, HttpResponse, HttpResponseBadRequest
from django.db.models import F  # ensure this exists
from django.db.models import Q, Prefetch
def _prefetched_tree():
    return (
        Building.objects.order_by("name").prefetch_related(
            Prefetch(
                "labs",
                queryset=Lab.objects.order_by("name").prefetch_related(
                    Prefetch("benches", queryset=Bench.objects.order_by("label"))
                ),
            )
        )
    )

def _current_instruments_qs():
    return (
        Instrument.objects.filter(placements__end_date__isnull=True)
        .select_related("category", "model")
        .distinct()
    )

def location_explorer(request):
    # tree (fully rendered; no API calls)
    buildings = _prefetched_tree()
    departments = Department.objects.order_by("name")
    statuses = dict(InstrumentStatus.STATUS_CHOICES)

    # selection + filters (same view)
    level = request.GET.get("level")      # building|lab|bench
    obj_id = request.GET.get("id")
    q = (request.GET.get("q") or "").strip()
    status = (request.GET.get("status") or "").strip()
    dept_id = (request.GET.get("dept") or "").strip()
    out_format = (request.GET.get("format") or "").strip()

    instruments_qs = None
    if level in {"building", "lab", "bench"} and obj_id:
        instruments_qs = _current_instruments_qs()
        if level == "building":
            instruments_qs = instruments_qs.filter(placements__building_id=obj_id)
        elif level == "lab":
            instruments_qs = instruments_qs.filter(placements__lab_id=obj_id)
        else:
            instruments_qs = instruments_qs.filter(placements__bench_id=obj_id)

        if q:
            instruments_qs = instruments_qs.filter(
                Q(name__icontains=q)
                | Q(serial_number__icontains=q)
                | Q(model__name__icontains=q)
                | Q(category__name__icontains=q)
            )
        if status:
            instruments_qs = instruments_qs.filter(status_history__status=status).order_by().distinct()
        if dept_id:
            instruments_qs = instruments_qs.filter(placements__department_id=dept_id).distinct()

    # CSV export from same view
    if instruments_qs is not None and out_format == "csv":
        import csv
        resp = HttpResponse(content_type="text/csv")
        resp["Content-Disposition"] = 'attachment; filename="location_instruments.csv"'
        writer = csv.writer(resp)
        writer.writerow(
            ["Instrument", "Serial", "Category", "Model", "Department", "Location", "Under Warranty"]
        )
        current_places = {
            p.instrument_id: p
            for p in InstrumentPlacement.objects.filter(
                instrument__in=instruments_qs, end_date__isnull=True
            ).select_related("department", "building", "lab", "bench")
        }
        for inst in instruments_qs.order_by("name"):
            p = current_places.get(inst.id)
            path = (
                " / ".join(
                    [
                        x
                        for x in [
                            p and p.building and p.building.name,
                            p and p.lab and p.lab.name,
                            p and p.bench and p.bench.label,
                        ]
                        if x
                    ]
                )
                if p
                else ""
            )
            writer.writerow(
                [
                    inst.name,
                    inst.serial_number,
                    inst.category.name if inst.category else "",
                    (inst.model and inst.model.name) or "",
                    (p and p.department and p.department.name) or "",
                    path,
                    "Yes" if inst.under_warranty else "No",
                ]
            )
        return resp

    # Build instrument rows (server-rendered) if selected
    instruments = []
    if instruments_qs is not None:
        placements = {
            p.instrument_id: p
            for p in InstrumentPlacement.objects.filter(
                instrument__in=instruments_qs, end_date__isnull=True
            ).select_related("department", "building", "lab", "bench")
        }
        for inst in instruments_qs.order_by("name"):
            p = placements.get(inst.id)
            path = (
                " / ".join(
                    [
                        x
                        for x in [
                            p and p.building and p.building.name,
                            p and p.lab and p.lab.name,
                            p and p.bench and p.bench.label,
                        ]
                        if x
                    ]
                )
                if p
                else ""
            )
            instruments.append(
                {
                    "id": inst.id,
                    "name": inst.name,
                    "serial": inst.serial_number,
                    "category": inst.category and inst.category.name or "",
                    "model": inst.model and inst.model.name or "",
                    "department": (p and p.department and p.department.name) or "",
                    "path": path,
                    "under_warranty": inst.under_warranty,
                }
            )

    return render(
        request,
        "location_explorer.html",
        {
            "buildings": buildings,
            "departments": departments,
            "statuses": statuses,
            "selected": {"level": level, "id": obj_id, "q": q, "status": status, "dept": dept_id},
            "instruments": instruments,
        },
    )

import sib_api_v3_sdk
from sib_api_v3_sdk.rest import ApiException

# Brevo API Configuration
brevo_configuration = sib_api_v3_sdk.Configuration()
brevo_configuration.api_key['api-key'] = ''

def send_otp_email(email, otp):
    api_instance = sib_api_v3_sdk.TransactionalEmailsApi(sib_api_v3_sdk.ApiClient(brevo_configuration))
    
    subject_line = f"Your One-Time Password (OTP): {otp} - Team Weighingmart"

    html_content = f"""
    <html>
    <body style="font-family: Arial, sans-serif; background-color: #f9f9f9; padding: 20px;">
        <div style="max-width: 600px; margin: auto; background: #ffffff; padding: 30px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.05);">
            <h2 style="color: #333;">Hello,</h2>
            <p style="font-size: 16px; color: #555;">Your One-Time Password (OTP) for logging in to <strong>Weighingmart</strong> is:</p>
            
            <div style="text-align: center; margin: 30px 0;">
                <span style="display: inline-block; font-size: 28px; font-weight: bold; letter-spacing: 2px; padding: 15px 30px; background-color: #f0f0f0; border: 2px dashed #333; border-radius: 6px; color: #000;">
                    {otp}
                </span>
            </div>

            <p style="font-size: 14px; color: #888;">This OTP is valid for 5 minutes. Please do not share it with anyone.</p>

            <hr style="margin: 40px 0; border: none; border-top: 1px solid #eee;" />

            <p style="margin-top: 20px; font-size: 14px; color: #666;">With regards,<br><strong>Team Weighingmart</strong></p>
        </div>
    </body>
    </html>
    """

    send_smtp_email = sib_api_v3_sdk.SendSmtpEmail(
        to=[{"email": email}],
        reply_to={"email": "noreply@weighingmart.in", "name": "Team Weighingmart"},
        html_content=html_content,
        sender={"name": "Team Weighingmart", "email": "enterprise@deepqueryengine.com"},
        subject=subject_line
    )

    api_instance.send_transac_email(send_smtp_email)

