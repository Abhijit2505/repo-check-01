# management_app/urls.py
from django.urls import path
from .views import *
# from management_app import totp_views
from django.conf.urls.static import static


urlpatterns = [ 
    path("admin-docs/", admin_docs, name="admin_docs"),
    path("i/<int:pk>/",instrument_public_detail, name="instrument-public-detail"),
    path("i/<int:pk>/qr.png", instrument_qr_png, name="instrument-qr-png"),
    path("dashboard/", DashboardView.as_view(), name="ems-dashboard"),
    path("dashboard/export.csv", export_dashboard_csv, name="ems-export-csv"),
    path("dashboard/export.xlsx", export_dashboard_xlsx, name="ems-export-xlsx"),
    path("locations/", location_explorer, name="location-explorer"),
    path("inventory/", inventory_view, name="ems-inventory"),

]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)